Randka 2.0 ❤️
Gotowa mobilna strona z animacjami, kartami wyboru, losowaniem i konfetti.
Otwórz index.html albo wrzuć go na hosting statyczny, aby uzyskać publiczny link.
